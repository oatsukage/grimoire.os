# Grimoire OS

Hosting-ready build for GitHub Pages.

## Deploy with GitHub Pages
1. Create a new public GitHub repository (for example `grimoire-os`).
2. Upload `index.html` to the root of the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. GitHub will provide the live site URL after deployment finishes.

Player data is stored locally in each player's browser and is not shared between users.
